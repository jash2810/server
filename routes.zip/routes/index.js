module.exports.seed = require('./seed')
module.exports.auth = require('./auth')
module.exports.food = require('./food')
module.exports.user = require('./user')