module.exports = [
    {
        cred: {
            username: "jash",
            password: "jash"
        },
        details: {
            name: "Jash Patel",
            contact: {
                mobile1: 8734804914,
                mobile2: 8200138967,
                email: "jashdetroj@gmail.com"
            },
            dob: 28/10/1998,
            age: 20,
            address: {
                street: "Science City",
                area: "Science City",
                pincode: "380060",
                city: "Ahmedabad",
                state: "Gujarat",
                country: "India"
            }
        },
        urls: {
            website: "www.jash.com",
            youtube: "www.youtube.com/jashdetroj"
        }
    }
]