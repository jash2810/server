module.exports = [
    {
        name: "Italian"
    },
    {
        name: "South Indian"
    },
    {
        name: "Punjabi"
    },
    {
        name: "Gujarati"
    }
]