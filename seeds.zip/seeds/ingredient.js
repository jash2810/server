module.exports = [
    {
        name: "Potato",
        category: "vegetable"
    },
    {
        name: "Tomato",
        category: "vegetable"
    },
    {
        name: "Grapes",
        category: "fruit"
    },
    {
        name: "Turmeric Powder",
        category: "spice"
    },
    {
        name: "Onion",
        category: "vegetable"
    },
    {
        name: "Milk",
        category: "drink"
    }
]